@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Deteksi Biji Kakao
cd /d "%~dp0"
if errorlevel 1 goto folder_error

echo ==============================================
echo       WEBSITE DETEKSI BIJI KAKAO
echo ==============================================
echo.
echo Letakkan best_model.pth di folder yang sama dengan app.py.
echo Website ini tidak menjalankan training.
echo.

if not exist "app.py" goto missing_files
if not exist "requirements.txt" goto missing_files

if exist ".venv\Scripts\python.exe" goto check_python

echo [1/4] Membuat environment khusus website dengan Python 3.12.
py -3.12 -c "import struct, sys; sys.exit(0 if struct.calcsize('P') == 8 else 1)" >nul 2>&1
if errorlevel 1 goto python_missing
py -3.12 -m venv ".venv"
if errorlevel 1 goto setup_error

:check_python
set "KAKAO_WEB_PYTHON=%CD%\.venv\Scripts\python.exe"
"%KAKAO_WEB_PYTHON%" -c "import struct, sys; sys.exit(0 if sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8 else 1)" >nul 2>&1
if errorlevel 1 goto environment_error

echo [2/4] Memeriksa PyTorch.
"%KAKAO_WEB_PYTHON%" -c "import torch, torchvision; from torchvision.ops import nms; assert torch.__version__.split('+')[0] == '2.9.1'; assert torchvision.__version__.split('+')[0] == '0.24.1'" >nul 2>&1
if not errorlevel 1 goto check_web_packages
echo Pemasangan awal memakai PyTorch CPU agar unduhan lebih kecil.
echo Untuk memakai GPU yang sudah tersedia, gunakan notebook peluncur.
echo Biarkan jendela ini terbuka sampai pemasangan selesai.
"%KAKAO_WEB_PYTHON%" -m pip --version >nul 2>&1
if not errorlevel 1 goto install_torch
"%KAKAO_WEB_PYTHON%" -m ensurepip --upgrade
if errorlevel 1 goto setup_error

:install_torch
"%KAKAO_WEB_PYTHON%" -m pip install --timeout 120 --retries 8 torch==2.9.1 torchvision==0.24.1 --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto setup_error

:check_web_packages
echo [3/4] Memeriksa library website.
"%KAKAO_WEB_PYTHON%" -c "import flask, waitress, PIL, pillow_heif; from importlib.metadata import version; assert version('Flask') == '3.1.2'; assert version('waitress') == '3.0.2'; assert version('Pillow') == '12.3.0'; assert version('pillow-heif') == '1.1.1'" >nul 2>&1
if not errorlevel 1 goto launch_web
"%KAKAO_WEB_PYTHON%" -m pip install --timeout 120 --retries 8 -r "requirements.txt"
if errorlevel 1 goto setup_error

:launch_web
echo [4/4] Membuka website pada browser.
echo Alamat: http://127.0.0.1:5000
echo.
echo Biarkan jendela ini terbuka selama website dipakai.
echo Untuk berhenti, tutup jendela ini atau tekan Ctrl+C.
echo.
"%KAKAO_WEB_PYTHON%" "app.py" --host 127.0.0.1 --port 5000 --open-browser
if errorlevel 1 goto launch_error
goto end

:python_missing
echo.
echo BELUM TERSEDIA: Python 3.12 64-bit beserta Python Launcher.
echo Instal Python 3.12 dari https://www.python.org/downloads/windows/
echo Centang instalasi Python Launcher, lalu jalankan file ini kembali.
echo Jika environment training sudah ada, buka JALANKAN_WEBSITE.ipynb
echo di VS Code dan pilih kernel Python yang dipakai training.
goto error_end

:environment_error
echo.
echo Environment .venv website tidak dapat digunakan.
echo File ini membutuhkan Python 3.12 64-bit.
echo Gunakan notebook peluncur dengan kernel training Anda, atau
echo ganti nama folder .venv website menjadi .venv_lama lalu ulangi.
echo Jangan mengubah environment di folder training.
goto error_end

:missing_files
echo.
echo File paket belum lengkap. Ekstrak seluruh ZIP terlebih dahulu.
echo BUKA_WEBSITE_WINDOWS.bat, app.py, dan requirements.txt
echo harus berada di folder hasil ekstrak yang sama.
goto error_end

:folder_error
echo.
echo Folder website tidak dapat dibuka.
echo Ekstrak ZIP ke folder lokal, misalnya D:\KAKAO_WEBSITE.
goto error_end

:setup_error
echo.
echo Pemasangan belum selesai. Periksa pesan kesalahan di atas.
echo Pastikan internet aktif dan ruang penyimpanan mencukupi,
echo kemudian klik dua kali file ini lagi untuk melanjutkan.
echo Alternatif: gunakan JALANKAN_WEBSITE.ipynb dengan kernel training.
goto error_end

:launch_error
echo.
echo Website berhenti karena kesalahan. Periksa pesan di atas.
echo Jika port 5000 sedang dipakai, hentikan website lama terlebih dahulu.
goto error_end

:error_end
echo.
pause
endlocal
exit /b 1

:end
endlocal
exit /b 0
