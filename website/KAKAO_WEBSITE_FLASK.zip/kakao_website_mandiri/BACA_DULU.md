# Website Deteksi dan Klasifikasi Biji Kakao

Website Flask mandiri untuk model **SSDLite-MobileNetV3-Large** hasil notebook `KAKAO_TRAINING_DARI_NOL.ipynb`. Tidak membutuhkan folder training, dataset, `src`, atau `run_pipeline.py`.

Sesuai penelitian: **Deteksi dan Klasifikasi Tingkat Fermentasi Biji Kakao Menggunakan SSDLite-MobileNetV3-Large Berbasis Analisis Citra Bentuk dan Warna**.

## 1. Letakkan model

Ekstrak seluruh ZIP, kemudian **salin `best_model.pth` hasil training ke folder yang sama dengan `app.py`**. Bobot model tidak disertakan dalam paket ini.

Notebook training menyimpannya di `hasil_penelitian/<nama_eksperimen>/checkpoints/best_model.pth`. Cukup salin berkas model tersebut; website tidak memerlukan salinan dataset atau notebook training.

```text
kakao_website_mandiri/
├── app.py
├── best_model.pth              ← salin model Anda ke sini
├── pengaturan.json
├── JALANKAN_WEBSITE.ipynb
├── BUKA_WEBSITE_WINDOWS.bat
├── requirements.txt
├── templates/
└── static/
```

Opsional: jika notebook training menghasilkan `inference_settings.json`, salin file itu ke folder ini juga. Website membaca nilai confidence-nya; lokasi model tetap memakai `best_model.pth` di folder website. Jalur lama ke folder training tidak diperlukan.

**Gunakan `.pth` dari notebook training tersebut.** File `.h5` biasanya milik TensorFlow/Keras dan tidak dapat dibuka oleh model PyTorch ini. Mengganti ekstensi `.h5` menjadi `.pth` tidak mengubah formatnya.

## 2. Jalankan tanpa mengetik perintah

### Pilihan A — notebook VS Code, cocok jika environment training sudah ada

1. Buka folder website di VS Code, kemudian buka **`JALANKAN_WEBSITE.ipynb`**.
2. Klik **Select Kernel**, lalu pilih Python/environment yang sebelumnya dipakai training. Model tetap berada dalam folder website; yang dipakai kembali hanya library Python yang sudah terpasang.
3. Jalankan sel dari atas ke bawah melalui tombol **▶**.
4. Klik **Mulai Website**, kemudian **Buka Website**. Jika sudah selesai, klik **Hentikan Website**.

Notebook ini hanya meluncurkan website. Tidak menjalankan training ulang. Jika kernel training sudah mendukung CUDA, website dapat menggunakan GPU tersebut.

### Pilihan B — klik dua kali file Windows

1. Pastikan **Python 3.12 64-bit dan Python Launcher** sudah terpasang.
2. Klik dua kali **`BUKA_WEBSITE_WINDOWS.bat`**.
3. Tunggu pemasangan awal selesai. Browser membuka **http://127.0.0.1:5000**.
4. Biarkan jendela launcher terbuka saat menggunakan website. Tutup jendela atau tekan **Ctrl+C** untuk berhenti.

Launcher membuat `.venv` tersendiri di folder website dan memasang PyTorch **CPU** agar unduhan awal lebih kecil. Tetap perlu internet pada pemasangan pertama. Pembukaan berikutnya memakai library yang sudah terpasang. Untuk memakai GPU tanpa mengunduh PyTorch lagi, gunakan Pilihan A.

Jika website lain masih memakai port 5000, hentikan yang lama terlebih dahulu. Jika model belum disalin, halaman tetap dapat dibuka, tetapi deteksi menampilkan petunjuk model dan tidak menghasilkan hitungan palsu.

## 3. Gunakan website

- **Unggah Gambar:** pilih foto, klik **Deteksi**, lalu lihat kotak deteksi, confidence, total biji, dan jumlah setiap kelas. Hasil yang berhasil otomatis masuk riwayat.
- **Kamera Langsung:** izinkan kamera, mulai deteksi, lalu arahkan kamera ke biji kakao. Hitungan mengikuti gambar terbaru; bukan penjumlahan antar-frame. Klik **Simpan Hasil** untuk menyimpan satu hasil ke riwayat.
- **Unduh Hasil:** menyimpan gambar dengan kotak deteksi yang sedang ditampilkan.
- **Riwayat:** melihat atau menghapus maksimal **10 hasil terakhir** pada browser/perangkat yang sama. Riwayat menggunakan `localStorage`, tanpa SQL atau database. Riwayat dapat hilang jika data browser dihapus.

Tiga kelas mengikuti model skripsi: **Tidak Fermentasi**, **Setengah Fermentasi**, dan **Full Fermentasi**. Angka hitungan berasal dari prediksi model yang melewati confidence yang dipakai, sehingga masih mungkin ada biji terlewat atau salah kelas.

## Pengaturan sederhana

Biasanya tidak perlu mengubah kode. File `pengaturan.json` menyediakan nama model, confidence, dan pilihan perangkat. `device: "auto"` menggunakan CUDA jika tersedia, selain itu CPU. Jangan mengubah nama/urutan kelas tanpa menyesuaikan model yang dilatih.

Nilai confidence pilihan dari validation dapat dibawa melalui `inference_settings.json`. Jika file tersebut tidak ada, nilai pada `pengaturan.json` dipakai. Turunkan confidence hanya bila sesuai hasil validation; ambang yang lebih rendah juga bisa menambah deteksi keliru.

## Membuka di Android atau iPhone

Tampilan menyesuaikan ukuran layar. Gunakan pengaturan akses jaringan pada notebook peluncur jika ingin membuka dari HP yang terhubung ke Wi-Fi yang sama. Alamat `127.0.0.1` hanya berlaku pada komputer tempat website dijalankan; HP memerlukan alamat IP komputer tersebut.

Pilihan **Jaringan lokal** pada notebook menampilkan calon alamat IP laptop. Gunakan alamat Wi-Fi yang sesuai pada HP; bila Windows meminta izin jaringan, izinkan pada jaringan pribadi yang Anda gunakan.

**Kamera browser di HP memerlukan HTTPS.** Akses HTTP melalui alamat IP Wi-Fi biasanya hanya dapat dipakai untuk unggah gambar, karena browser membatasi izin kamera pada koneksi yang tidak aman. `localhost` di komputer sendiri dapat memakai kamera. Kecepatan kamera bergantung pada model, CPU/GPU, dan jaringan.

## Catatan

- Tidak ada login, database, atau koneksi wajib ke folder training.
- Tidak ada contoh angka hasil yang disamarkan sebagai prediksi model.
- File gambar diproses untuk inferensi; riwayat disimpan di browser berupa thumbnail dan hitungan, bukan database server.
- Hasil training dan bobot model Anda tetap menjadi penentu kualitas deteksi.
