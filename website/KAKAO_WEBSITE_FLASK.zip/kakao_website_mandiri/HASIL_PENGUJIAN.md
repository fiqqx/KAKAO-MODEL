# Pemeriksaan paket website — 15 Oktober 2026

Paket ini diuji pada Linux CPU dengan Python 3.12, PyTorch 2.9.1, dan
TorchVision 0.24.1. Model uji berasal dari eksekusi sintetis notebook
`KAKAO_TRAINING_DARI_NOL.ipynb`; bukan model hasil penelitian kakao pengguna.
Bobot dan gambar uji tidak disertakan dalam ZIP.

- Dua belas kelompok pemeriksaan backend lulus: pemuatan checkpoint notebook,
  pure state_dict, penolakan metadata arsitektur/kelas yang salah, inferensi
  dan kesamaan box/hitungan, gambar HEIF, orientasi EXIF, berkas tidak valid,
  batas ukuran/piksel, model hilang/H5, pengaturan rusak, prioritas confidence,
  serta CUDA yang diminta tetapi tidak tersedia. Kesalahan tidak menjadi nol.
- Pengujian Chromium lulus untuk unggahan tiga kelas, hasil nol, unduhan JPEG,
  gambar rusak, riwayat bertahan setelah refresh, lihat/hapus riwayat, dan
  halaman yang tetap tersedia ketika model belum siap.
- Kamera simulasi lulus: satu permintaan aktif, jumlah frame terbaru,
  penyimpanan manual, menghentikan semua track kamera, dan mengabaikan hasil
  terlambat setelah Stop. Kamera tidak mengakumulasi hitungan antar-frame.
- Empat halaman diuji pada lebar 360, 390, 430, dan 1280 piksel: 16 pemeriksaan
  tanpa overflow horizontal; tombol terbaca dan memiliki tinggi minimal 44 px.
- Notebook launcher dieksekusi pada kernel IPython dalam folder terpisah
  dengan spasi pada nama folder, tanpa kode/dataset training. Run All hanya
  menyiapkan kontrol. Start, pemuatan model satu folder, inferensi, pemakaian
  alamat lokal/jaringan, Start berulang, serta Stop lulus.
- Lokasi checkpoint lama dalam `inference_settings.json` sengaja dibuat tidak
  ada; website tetap memuat `best_model.pth` di foldernya sendiri.
- BAT diperiksa alur label, pengutipan path, ASCII/CRLF, serta instalasi
  environment tersendiri tanpa mengubah Execution Policy atau meminta admin.

Windows/driver NVIDIA dan kamera Android/iPhone fisik belum diuji dari cloud.
Kamera ponsel membutuhkan HTTPS; responsif pada layar ponsel tidak mengubah
persyaratan keamanan browser tersebut. Kualitas deteksi bergantung pada model
yang Anda latih, bukan tampilan website.
