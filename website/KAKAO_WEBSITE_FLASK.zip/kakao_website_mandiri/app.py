"""Website Flask mandiri. Letakkan best_model.pth di sebelah file ini."""

from __future__ import annotations

from io import BytesIO
import warnings

from flask import Flask, jsonify, render_template, request
from PIL import Image, ImageOps, UnidentifiedImageError
from werkzeug.exceptions import RequestEntityTooLarge

from model_service import InferenceService, InferenceUnavailable, load_options

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pillow_heif = None


def create_app(config_override=None, inference_service=None):
    app = Flask(__name__)
    try:
        options = load_options(config_override)
        settings_error = None
    except (ValueError, OSError, TypeError) as error:
        # Halaman panduan tetap tersedia meski pengaturan salah.
        options = {
            "MAX_CONTENT_LENGTH": 15 * 1024 * 1024, "MAX_IMAGE_PIXELS": 50_000_000,
            "HOST": "127.0.0.1", "PORT": 5000,
        }
        settings_error = f"Pengaturan belum benar: {error}"
    app.config.update(options)
    app.json.ensure_ascii = False
    if settings_error:
        class UnavailableSettingsService:
            ready = False
            device = "belum tersedia"
            error = settings_error

            def health(self):
                return {"ready": False, "device": self.device, "error": self.error, "message": self.error}

        service = UnavailableSettingsService()
    else:
        service = inference_service if inference_service is not None else InferenceService(app.config)
    app.extensions["inference_service"] = service
    if not service.ready:
        app.logger.warning("%s", service.error)

    def health_payload():
        if callable(getattr(service, "health", None)):
            return service.health()
        return {"ready": bool(service.ready), "device": str(service.device), "error": service.error,
                "message": "Model siap digunakan." if service.ready else service.error}

    @app.context_processor
    def model_context():
        return {"model_status": health_payload()}

    @app.get("/")
    def home():
        return render_template("home.html")

    @app.get("/upload")
    def upload():
        return render_template("upload.html")

    @app.get("/camera")
    def camera():
        return render_template("camera.html")

    @app.get("/history")
    def history():
        return render_template("history.html")

    @app.get("/api/health")
    def health():
        return jsonify(health_payload())

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_error):
        limit = app.config["MAX_CONTENT_LENGTH"] / (1024 * 1024)
        return jsonify(error=f"Gambar terlalu besar. Ukuran maksimal {limit:g} MB."), 413

    @app.post("/api/predict")
    def predict():
        if not service.ready:
            return jsonify(error=service.error or "Model belum siap. Letakkan best_model.pth di folder website."), 503
        uploaded = request.files.get("image")
        if uploaded is None:
            return jsonify(error="Pilih atau kirim gambar terlebih dahulu."), 400
        if request.form.get("mode", "upload") not in {"upload", "camera"}:
            return jsonify(error="Mode deteksi harus upload atau camera."), 400
        try:
            raw = uploaded.read()
            if not raw:
                return jsonify(error="Berkas gambar kosong."), 400
            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                with Image.open(BytesIO(raw)) as opened:
                    if opened.format not in {"JPEG", "PNG", "WEBP", "HEIF", "HEIC"}:
                        return jsonify(error="Gunakan gambar JPEG, PNG, WebP, atau HEIC/HEIF."), 415
                    if opened.width * opened.height > app.config["MAX_IMAGE_PIXELS"]:
                        return jsonify(error="Resolusi gambar terlalu besar. Kecilkan gambar terlebih dahulu."), 413
                    opened.load()
                    image = ImageOps.exif_transpose(opened).convert("RGB")
        except (Image.DecompressionBombError, Image.DecompressionBombWarning):
            return jsonify(error="Resolusi gambar terlalu besar. Kecilkan gambar terlebih dahulu."), 413
        except UnidentifiedImageError:
            return jsonify(error="Berkas bukan gambar yang didukung atau rusak. HEIC membutuhkan pillow-heif."), 415
        except (OSError, ValueError, SyntaxError):
            return jsonify(error="Gambar tidak dapat dibaca. Pilih berkas gambar yang valid."), 400
        try:
            return jsonify(service.predict(image))
        except InferenceUnavailable as error:
            return jsonify(error=str(error)), 503
        except Exception:
            app.logger.exception("Inferensi gambar gagal")
            return jsonify(error="Deteksi gagal. Periksa pesan pada jendela aplikasi, kemudian coba kembali."), 503

    return app


if __name__ == "__main__":
    import argparse
    from threading import Timer
    import webbrowser
    from waitress import create_server

    parser = argparse.ArgumentParser(description="Website deteksi biji kakao mandiri")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--open-browser", action="store_true")
    args = parser.parse_args()
    application = create_app()
    host = args.host or application.config["HOST"]
    port = args.port if args.port is not None else application.config["PORT"]
    if not 1 <= port <= 65535:
        parser.error("port harus antara 1 dan 65535")
    server = create_server(application, host=host, port=port, threads=4)
    url = f"http://{'127.0.0.1' if host in {'0.0.0.0', '::'} else host}:{port}"
    print(f"Buka website: {url}", flush=True)
    print("Tutup jendela ini atau tekan Ctrl+C untuk menghentikan website.", flush=True)
    if args.open_browser:
        timer = Timer(0.5, webbrowser.open, args=(url,))
        timer.daemon = True
        timer.start()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.task_dispatcher.shutdown(cancel_pending=True, timeout=3)
        server.close()
