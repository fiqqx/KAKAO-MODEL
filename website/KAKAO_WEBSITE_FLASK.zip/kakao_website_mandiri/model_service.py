"""Inferensi mandiri untuk model notebook KAKAO_TRAINING_DARI_NOL.ipynb.

Tidak mengimpor file proyek training dan tidak mengunduh bobot pretrained.
"""

from __future__ import annotations

import base64
from collections.abc import Mapping
from datetime import datetime, timezone
from io import BytesIO
import json
import math
import os
from pathlib import Path
from threading import Lock
from time import perf_counter
from uuid import uuid4

from PIL import Image, ImageDraw, ImageFont
import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large
from torchvision.transforms.functional import pil_to_tensor


BASE_DIR = Path(__file__).resolve().parent
MODEL_NAME = "ssdlite320_mobilenet_v3_large"
CLASS_NAMES = {
    0: "background",
    1: "Tidak Fermentasi",
    2: "Setengah Fermentasi",
    3: "Full Fermentasi",
}
COLORS = {1: "#d62728", 2: "#b97800", 3: "#238636"}


class InferenceUnavailable(RuntimeError):
    """Model belum siap; berbeda dari hasil sah dengan nol objek."""


def _read_json(path):
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"Pengaturan tidak dapat dibaca: {path.name} ({error}).") from error
    if not isinstance(value, dict):
        raise ValueError(f"Isi {path.name} harus object JSON.")
    return value


def _probability(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} harus angka antara 0 dan 1.")
    number = float(value)
    if not math.isfinite(number) or not 0 <= number <= 1:
        raise ValueError(f"{name} harus angka antara 0 dan 1.")
    return number


def load_options(overrides=None):
    """Hanya folder website yang dibaca; path folder training tidak digunakan."""
    overrides = dict(overrides or {})
    root = Path(overrides.get("BASE_DIR", BASE_DIR)).expanduser().resolve()
    settings = _read_json(root / "pengaturan.json")
    inference = _read_json(root / "inference_settings.json")
    confidence = settings.get("confidence_threshold", 0.50)
    source = "pengaturan.json" if "confidence_threshold" in settings else "default 0.50"
    if "confidence_threshold" in inference:
        confidence = inference["confidence_threshold"]
        source = "inference_settings.json (hasil validation)"
    # Prioritas pengaturan eksplisit server > sidecar validation > pengaturan.json.
    if os.environ.get("WEB_CONFIDENCE_THRESHOLD") is not None:
        confidence = os.environ["WEB_CONFIDENCE_THRESHOLD"]
        source = "pengaturan server"
    if "WEB_CONFIDENCE_THRESHOLD" in overrides:
        confidence = overrides["WEB_CONFIDENCE_THRESHOLD"]
        source = "pengaturan server"
    options = {
        "BASE_DIR": root,
        "MODEL_PATH": os.environ.get("KAKAO_MODEL_FILE", settings.get("model_file", "best_model.pth")),
        "WEB_CONFIDENCE_THRESHOLD": _probability(confidence, "confidence_threshold"),
        "THRESHOLD_SOURCE": source,
        "DEVICE": os.environ.get("WEB_DEVICE", settings.get("device", "auto")),
        "HOST": settings.get("host", "127.0.0.1"),
        "PORT": settings.get("port", 5000),
        "MAX_CONTENT_LENGTH": 15 * 1024 * 1024,
        "MAX_IMAGE_PIXELS": 50_000_000,
    }
    options.update(overrides)
    if "CHECKPOINT_PATH" in overrides and "MODEL_PATH" not in overrides:
        options["MODEL_PATH"] = overrides["CHECKPOINT_PATH"]
    options["WEB_CONFIDENCE_THRESHOLD"] = _probability(
        options["WEB_CONFIDENCE_THRESHOLD"], "confidence_threshold"
    )
    port = options["PORT"]
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("port pada pengaturan.json harus bilangan bulat 1–65535.")
    return options


def _saved_value(checkpoint, key, default):
    config = checkpoint.get("config", {})
    hyperparameters = checkpoint.get("hyperparameters", {})
    if not isinstance(config, Mapping) or not isinstance(hyperparameters, Mapping):
        raise ValueError("Metadata config/hyperparameters pada model tidak valid.")
    return config.get(key.upper(), hyperparameters.get(key.lower(), default))


def load_model_file(path):
    """Muat state_dict aman pada CPU, kemudian cocokkan arsitektur secara ketat."""
    path = Path(path)
    if path.suffix.casefold() in {".h5", ".hdf5", ".keras"}:
        raise ValueError(
            "File .h5 adalah format Keras/TensorFlow. Training notebook ini memakai PyTorch; "
            "gunakan best_model.pth asli, jangan hanya mengganti ekstensi file."
        )
    if path.suffix.casefold() not in {".pth", ".pt"}:
        raise ValueError("Model harus berupa best_model.pth dari notebook training.")
    if not path.is_file():
        h5_files = list(path.parent.glob("*.h5")) + list(path.parent.glob("*.keras"))
        hint = " File .h5/.keras yang ditemukan tidak cocok; gunakan .pth asli notebook." if h5_files else ""
        raise FileNotFoundError(
            f"Letakkan best_model.pth hasil training di folder yang sama dengan app.py.{hint}"
        )
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(checkpoint, Mapping) or not checkpoint:
        raise ValueError("File model tidak berisi checkpoint atau state_dict yang valid.")
    if "model_state_dict" in checkpoint:
        state = checkpoint["model_state_dict"]
        config = checkpoint.get("config", {})
        if not isinstance(config, Mapping):
            raise ValueError("Metadata config checkpoint tidak valid.")
        saved_model = checkpoint.get("model_name", config.get("MODEL_NAME"))
        saved_num_classes = checkpoint.get("num_classes", config.get("NUM_CLASSES"))
        saved_classes = checkpoint.get("class_names", config.get("CLASS_NAMES"))
        if saved_model is not None and saved_model != MODEL_NAME:
            raise ValueError(f"Arsitektur model tidak sesuai: {saved_model}.")
        if saved_num_classes is not None and saved_num_classes != 4:
            raise ValueError("Jumlah kelas model harus 4: tiga kelas biji dan background.")
        if saved_classes is not None:
            if not isinstance(saved_classes, Mapping):
                raise ValueError("Metadata class_names model harus berisi pemetaan label.")
            try:
                saved_classes = {int(label): name for label, name in saved_classes.items()}
            except (TypeError, ValueError) as error:
                raise ValueError("Metadata label model tidak valid.") from error
            if saved_classes != CLASS_NAMES:
                raise ValueError("Urutan/nama kelas checkpoint tidak cocok dengan notebook kakao.")
        nms = _probability(_saved_value(checkpoint, "NMS_IOU_THRESHOLD", 0.55), "NMS_IOU_THRESHOLD")
        score = _probability(_saved_value(checkpoint, "MAP_SCORE_THRESHOLD", 0.001), "MAP_SCORE_THRESHOLD")
        max_detections = _saved_value(checkpoint, "MAX_DETECTIONS_PER_IMAGE", 300)
    elif all(isinstance(key, str) and torch.is_tensor(value) for key, value in checkpoint.items()):
        # Pure state_dict boleh dipakai jika arsitektur dan label tetap sama.
        state, nms, score, max_detections = checkpoint, 0.55, 0.001, 300
    else:
        raise ValueError("Checkpoint harus memiliki model_state_dict atau berisi pure state_dict.")
    if not isinstance(state, Mapping) or not state or not all(torch.is_tensor(value) for value in state.values()):
        raise ValueError("model_state_dict tidak valid.")
    if (isinstance(max_detections, bool) or not isinstance(max_detections, int)
            or not 1 <= max_detections <= 10_000):
        raise ValueError("MAX_DETECTIONS_PER_IMAGE checkpoint tidak valid.")
    model = ssdlite320_mobilenet_v3_large(
        weights=None, weights_backbone=None, num_classes=4,
        score_thresh=score, nms_thresh=nms, detections_per_img=max_detections,
    )
    model.load_state_dict(state, strict=True)
    return model


def draw_predictions(image, boxes, labels, scores):
    canvas = image.copy()
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default(size=max(12, round(max(image.size) / 90)))
    line_width = max(2, round(max(image.size) / 500))
    width, height = image.size
    for box, label, score in zip(boxes, labels, scores):
        x1, y1, x2, y2 = box
        color = COLORS[label]
        draw.rectangle((x1, y1, x2, y2), outline=color, width=line_width)
        text = f"{CLASS_NAMES[label]} {score:.2f}"
        bounds = draw.textbbox((0, 0), text, font=font)
        text_width, text_height = bounds[2] - bounds[0], bounds[3] - bounds[1]
        text_x = max(0, min(x1, width - text_width - 4))
        text_y = max(0, y1 - text_height - 6)
        draw.rectangle((text_x, text_y, min(width, text_x + text_width + 4),
                        min(height, text_y + text_height + 4)), fill=color)
        draw.text((text_x + 2, text_y + 2 - bounds[1]), text, font=font, fill="white")
    return canvas


class InferenceService:
    """Satu model untuk seluruh request, dengan forward yang dikunci."""

    def __init__(self, options, model=None):
        self._lock = Lock()
        self.model = None
        self.error = None
        self.device = "belum tersedia"
        self.threshold = _probability(options["WEB_CONFIDENCE_THRESHOLD"], "confidence_threshold")
        self.threshold_source = options.get("THRESHOLD_SOURCE", "pengaturan server")
        try:
            requested = str(options.get("DEVICE", "auto")).lower()
            if requested not in {"auto", "cuda", "cpu"}:
                raise ValueError("device harus auto, cuda, atau cpu.")
            if requested == "cuda" and not torch.cuda.is_available():
                raise RuntimeError("GPU CUDA diminta tetapi belum siap. Periksa Python/PyTorch GPU Anda.")
            self.device = "cuda" if requested != "cpu" and torch.cuda.is_available() else "cpu"
            if self.device == "cpu":
                torch.set_num_threads(min(4, os.cpu_count() or 1))
            if model is None:
                path = Path(options["MODEL_PATH"]).expanduser()
                if not path.is_absolute():
                    path = Path(options.get("BASE_DIR", BASE_DIR)) / path
                model = load_model_file(path)
            self.model = model.to(self.device).eval()
        except Exception as error:
            self.error = f"Model belum siap: {error}"

    @property
    def ready(self):
        return self.model is not None and self.error is None

    def health(self):
        return {
            "ready": bool(self.ready), "device": str(self.device), "error": self.error,
            "message": "Model siap digunakan." if self.ready else self.error,
            "confidence_threshold": self.threshold, "threshold_source": self.threshold_source,
        }

    @torch.inference_mode()
    def predict(self, image):
        if not self.ready:
            raise InferenceUnavailable(self.error or "Model belum siap.")
        started = perf_counter()
        image = image.convert("RGB")
        # Resize 320 dan normalisasi sudah dikerjakan transform internal SSDLite.
        tensor = pil_to_tensor(image).to(dtype=torch.float32).div(255.0)
        with self._lock:
            outputs = self.model([tensor.to(self.device)])
            if not isinstance(outputs, (list, tuple)) or len(outputs) != 1:
                raise ValueError("Model harus menghasilkan satu prediksi per gambar.")
            prediction = outputs[0]
            boxes = prediction["boxes"].detach().to("cpu", dtype=torch.float32).reshape(-1, 4)
            labels = prediction["labels"].detach().to("cpu", dtype=torch.int64).reshape(-1)
            scores = prediction["scores"].detach().to("cpu", dtype=torch.float32).reshape(-1)
        if not len(boxes) == len(labels) == len(scores):
            raise ValueError("Jumlah boxes, labels, dan scores tidak sama.")
        if not bool(torch.isfinite(boxes).all()) or not bool(torch.isfinite(scores).all()):
            raise ValueError("Prediksi model berisi nilai yang tidak valid.")
        if bool(((scores < 0) | (scores > 1)).any()):
            raise ValueError("Confidence model harus antara 0 dan 1.")
        if set(labels.tolist()) - {1, 2, 3}:
            raise ValueError("Label keluaran model tidak sesuai tiga kelas fermentasi.")
        if len(boxes) and bool(((boxes[:, 2:] - boxes[:, :2]) < 0).any()):
            raise ValueError("Bounding box keluaran model tidak valid.")
        keep = scores >= self.threshold
        box_list, label_list, score_list = boxes[keep].tolist(), labels[keep].tolist(), scores[keep].tolist()
        counts = {CLASS_NAMES[label]: label_list.count(label) for label in (1, 2, 3)}
        canvas = draw_predictions(image, box_list, label_list, score_list)
        buffer = BytesIO()
        canvas.save(buffer, format="JPEG", quality=90)
        return {
            "result_id": uuid4().hex,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "image_base64": base64.b64encode(buffer.getvalue()).decode("ascii"),
            "image_mime": "image/jpeg", "width": image.width, "height": image.height,
            "boxes": box_list, "labels": label_list, "scores": score_list,
            "counts": counts, "total": len(label_list), "confidence_threshold": self.threshold,
            "inference_ms": round((perf_counter() - started) * 1000, 1),
        }
